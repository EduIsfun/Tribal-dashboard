		
	<?php
$html = '<!DOCTYPE HTML>
					<html>
					 <body style="margin:0;padding:0;"> 
					 <div style="width:100%;margin-top:40px;">
						 <div style="width:42%;float:left;margin-left:30px;border:1px solid #000;">
						 <table >									
							<tr><td style="font-size:16px;text-transform:uppercase;"><strong>1 LNV\ ISI01752\EXP AUG 2018\</strong></td></tr>
							<tr><td style="margin: 0;font-size: 14px;text-transform:uppercase;">(SOCIAL SERVICE CENTRE)</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">HOSURU JANUARAPETTE</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">KARNATAKA</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">BIJAPUR, 586 115</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">INDIA</td></tr>
						  </table> 
						 </div>
						 <div style="float:left;width:42%;margin-left:30px;border:1px solid #000;">
							<table >									
							<tr><td style="font-size:16px;text-transform:uppercase;"><strong>1 LNV\ ISI01752\EXP AUG 2018\</strong></td></tr>
							<tr><td style="margin: 0;font-size: 14px;text-transform:uppercase;">(SOCIAL SERVICE CENTRE)</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">HOSURU JANUARAPETTE</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">KARNATAKA</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">BIJAPUR, 586 115</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">INDIA</td></tr>
						  </table> 
						  </div>
					 </div>
					  <div style="width:100%;margin-top:40px;">
						 <div style="width:42%;float:left;margin-left:30px;border:1px solid #000;">
						 <table >									
							<tr><td style="font-size:16px;text-transform:uppercase;"><strong>1 LNV\ ISI01752\EXP AUG 2018\</strong></td></tr>
							<tr><td style="margin: 0;font-size: 14px;text-transform:uppercase;">(SOCIAL SERVICE CENTRE)</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">HOSURU JANUARAPETTE</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">KARNATAKA</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">BIJAPUR, 586 115</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">INDIA</td></tr>
						  </table> 
						 </div>
						 <div style="float:left;width:42%;margin-left:30px;border:1px solid #000;">
							<table >									
							<tr><td style="font-size:16px;text-transform:uppercase;"><strong>1 LNV\ ISI01752\EXP AUG 2018\</strong></td></tr>
							<tr><td style="margin: 0;font-size: 14px;text-transform:uppercase;">(SOCIAL SERVICE CENTRE)</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">HOSURU JANUARAPETTE</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">KARNATAKA</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">BIJAPUR, 586 115</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">INDIA</td></tr>
						  </table> 
						  </div>
					 </div>
					  <div style="width:100%;margin-top:40px;">
						 <div style="width:42%;float:left;margin-left:30px;border:1px solid #000;">
						 <table >									
							<tr><td style="font-size:16px;text-transform:uppercase;"><strong>1 LNV\ ISI01752\EXP AUG 2018\</strong></td></tr>
							<tr><td style="margin: 0;font-size: 14px;text-transform:uppercase;">(SOCIAL SERVICE CENTRE)</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">HOSURU JANUARAPETTE</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">KARNATAKA</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">BIJAPUR, 586 115</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">INDIA</td></tr>
						  </table> 
						 </div>
						 <div style="float:left;width:42%;margin-left:30px;border:1px solid #000;">
							<table >									
							<tr><td style="font-size:16px;text-transform:uppercase;"><strong>1 LNV\ ISI01752\EXP AUG 2018\</strong></td></tr>
							<tr><td style="margin: 0;font-size: 14px;text-transform:uppercase;">(SOCIAL SERVICE CENTRE)</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">HOSURU JANUARAPETTE</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">KARNATAKA</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">BIJAPUR, 586 115</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">INDIA</td></tr>
						  </table> 
						  </div>
					 </div>
					  <div style="width:100%;margin-top:40px;">
						 <div style="width:42%;float:left;margin-left:30px;border:1px solid #000;">
						 <table >									
							<tr><td style="font-size:16px;text-transform:uppercase;"><strong>1 LNV\ ISI01752\EXP AUG 2018\</strong></td></tr>
							<tr><td style="margin: 0;font-size: 14px;text-transform:uppercase;">(SOCIAL SERVICE CENTRE)</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">HOSURU JANUARAPETTE</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">KARNATAKA</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">BIJAPUR, 586 115</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">INDIA</td></tr>
						  </table> 
						 </div>
						 <div style="float:left;width:42%;margin-left:30px;border:1px solid #000;">
							<table >									
							<tr><td style="font-size:16px;text-transform:uppercase;"><strong>1 LNV\ ISI01752\EXP AUG 2018\</strong></td></tr>
							<tr><td style="margin: 0;font-size: 14px;text-transform:uppercase;">(SOCIAL SERVICE CENTRE)</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">HOSURU JANUARAPETTE</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">KARNATAKA</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">BIJAPUR, 586 115</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">INDIA</td></tr>
						  </table> 
						  </div>
					 </div>
					  <div style="width:100%;margin-top:40px;">
						 <div style="width:42%;float:left;margin-left:30px;border:1px solid #000;">
						 <table >									
							<tr><td style="font-size:16px;text-transform:uppercase;"><strong>1 LNV\ ISI01752\EXP AUG 2018\</strong></td></tr>
							<tr><td style="margin: 0;font-size: 14px;text-transform:uppercase;">(SOCIAL SERVICE CENTRE)</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">HOSURU JANUARAPETTE</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">KARNATAKA</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">BIJAPUR, 586 115</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">INDIA</td></tr>
						  </table> 
						 </div>
						 <div style="float:left;width:42%;margin-left:30px;border:1px solid #000;">
							<table >									
							<tr><td style="font-size:16px;text-transform:uppercase;"><strong>1 LNV\ ISI01752\EXP AUG 2018\</strong></td></tr>
							<tr><td style="margin: 0;font-size: 14px;text-transform:uppercase;">(SOCIAL SERVICE CENTRE)</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">HOSURU JANUARAPETTE</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">KARNATAKA</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">BIJAPUR, 586 115</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">INDIA</td></tr>
						  </table> 
						  </div>
					 </div>
					  <div style="width:100%;margin-top:40px;">
						 <div style="width:42%;float:left;margin-left:30px;border:1px solid #000;">
						 <table >									
							<tr><td style="font-size:16px;text-transform:uppercase;"><strong>1 LNV\ ISI01752\EXP AUG 2018\</strong></td></tr>
							<tr><td style="margin: 0;font-size: 14px;text-transform:uppercase;">(SOCIAL SERVICE CENTRE)</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">HOSURU JANUARAPETTE</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">KARNATAKA</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">BIJAPUR, 586 115</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">INDIA</td></tr>
						  </table> 
						 </div>
						 <div style="float:left;width:42%;margin-left:30px;border:1px solid #000;">
							<table >									
							<tr><td style="font-size:16px;text-transform:uppercase;"><strong>1 LNV\ ISI01752\EXP AUG 2018\</strong></td></tr>
							<tr><td style="margin: 0;font-size: 14px;text-transform:uppercase;">(SOCIAL SERVICE CENTRE)</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">HOSURU JANUARAPETTE</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">KARNATAKA</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">BIJAPUR, 586 115</td></tr>
							<tr><td  style="margin: 0;font-size: 14px;text-transform:uppercase;">INDIA</td></tr>
						  </table> 
						  </div>
					 </div>
					 </body> 
					 </html>
	';					

include("mpdf.php");
$mpdf=new mPDF('en-GB-x','A4','','',10,10,10,10,6,3);
$mpdf->SetDisplayMode('fullpage');
$mpdf->WriteHTML($html);
$mpdf->Output($path,'I');

///include("mpdf.php");
//$mpdf=new mPDF('c','A4','','',32,25,27,25,16,13); 
//$mpdf=new mPDF('en-GB-x','A4','','',10,10,10,10,6,3);
//$mpdf->SetDisplayMode('fullpage');
//$mpdf->list_indent_first_level = 0;	// 1 or 0 - whether to indent the first level of a list
//$mpdf->WriteHTML($html,2);
//$mpdf->WriteHTML($html);
//$mpdf->WriteHTML($html);

//$mpdf->Output('mpdf.pdf','I');
 //$mpdf->Output('mpdf.pdf','F');
exit;
//==============================================================
//==============================================================
//==============================================================


?>