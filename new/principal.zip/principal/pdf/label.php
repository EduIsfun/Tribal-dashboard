			<?php

$html = '<html>
	<body>
		<div style="width:43%;margin-top:20px;  background:#FFF;  padding:20px;float:left;">
			  
				   <p style="margin: 0;font-size: 16px;margin-top:35px;">15|LNV|26-12-2017</p> 
				   <p style="margin: 0;">For 10, Institutional Area, Lodi Road</p> 
				   <p style="margin: 0;">New Delhi, 110003</p> 
				   <p style="margin: 0;">India</p>
    
		  </div>
		  <div style="width:43%;margin-top:20px;  background:#FFF;  padding:20px;float:left;">
			  
				   <p style="margin: 0;font-size: 16px;margin-top:35px;">15|LNV|26-12-2017</p> 
				   <p style="margin: 0;">For 10, Institutional Area, Lodi Road</p> 
				   <p style="margin: 0;">New Delhi, 110003</p> 
				   <p style="margin: 0;">India</p>
    
		  </div>
		  <div style="width:43%;  background:#FFF;  padding:20px;float:left;">
			  
				   <p style="margin: 0;font-size: 16px;">15|LNV|26-12-2017</p> 
				   <p style="margin: 0;">For 10, Institutional Area, Lodi Road</p> 
				   <p style="margin: 0;">New Delhi, 110003</p> 
				   <p style="margin: 0;">India</p>
    
		  </div>
		  <div style="width:43%;  background:#FFF;  padding:20px;float:left;">
			  
				   <p style="margin: 0;font-size: 16px;">15|LNV|26-12-2017</p> 
				   <p style="margin: 0;">For 10, Institutional Area, Lodi Road</p> 
				   <p style="margin: 0;">New Delhi, 110003</p> 
				   <p style="margin: 0;">India</p>
    
		  </div>
		  <div style="width:43%;  background:#FFF;  padding:20px;float:left;">
			  
				   <p style="margin: 0;font-size: 16px;">15|LNV|26-12-2017</p> 
				   <p style="margin: 0;">For 10, Institutional Area, Lodi Road</p> 
				   <p style="margin: 0;">New Delhi, 110003</p> 
				   <p style="margin: 0;">India</p>
    
		  </div>
		  <div style="width:43%;  background:#FFF;  padding:20px;float:left;">
			  
				   <p style="margin: 0;font-size: 16px;">15|LNV|26-12-2017</p> 
				   <p style="margin: 0;">For 10, Institutional Area, Lodi Road</p> 
				   <p style="margin: 0;">New Delhi, 110003</p> 
				   <p style="margin: 0;">India</p>
    
		  </div>
		  <div style="width:43%;  background:#FFF;  padding:20px;float:left;">
			  
				   <p style="margin: 0;font-size: 16px;">15|LNV|26-12-2017</p> 
				   <p style="margin: 0;">For 10, Institutional Area, Lodi Road</p> 
				   <p style="margin: 0;">New Delhi, 110003</p> 
				   <p style="margin: 0;">India</p>
    
		  </div>
		  <div style="width:43%;  background:#FFF;  padding:20px;float:left;">
			  
				   <p style="margin: 0;font-size: 16px;">15|LNV|26-12-2017</p> 
				   <p style="margin: 0;">For 10, Institutional Area, Lodi Road</p> 
				   <p style="margin: 0;">New Delhi, 110003</p> 
				   <p style="margin: 0;">India</p>
    
		  </div>
		  <div style="width:43%;  background:#FFF;  padding:20px;float:left;">
			  
				   <p style="margin: 0;font-size: 16px;">15|LNV|26-12-2017</p> 
				   <p style="margin: 0;">For 10, Institutional Area, Lodi Road</p> 
				   <p style="margin: 0;">New Delhi, 110003</p> 
				   <p style="margin: 0;">India</p>
    
		  </div>
		  <div style="width:43%;  background:#FFF;  padding:20px;float:left;">
			  
				   <p style="margin: 0;font-size: 16px;">15|LNV|26-12-2017</p> 
				   <p style="margin: 0;">For 10, Institutional Area, Lodi Road</p> 
				   <p style="margin: 0;">New Delhi, 110003</p> 
				   <p style="margin: 0;">India</p>
    
		  </div>
		  <div style="width:43%;  background:#FFF;  padding:20px;float:left;">
			  
				   <p style="margin: 0;font-size: 16px;">15|LNV|26-12-2017</p> 
				   <p style="margin: 0;">For 10, Institutional Area, Lodi Road</p> 
				   <p style="margin: 0;">New Delhi, 110003</p> 
				   <p style="margin: 0;">India</p>
    
		  </div>
		  <div style="width:43%;  background:#FFF;  padding:20px;float:left;">
			  
				   <p style="margin: 0;font-size: 16px;">15|LNV|26-12-2017</p> 
				   <p style="margin: 0;">For 10, Institutional Area, Lodi Road</p> 
				   <p style="margin: 0;">New Delhi, 110003</p> 
				   <p style="margin: 0;">India</p>
    
		  </div>
		   <div style="width:43%;  background:#FFF;  padding:20px;float:left;">
			  
				   <p style="margin: 0;font-size: 16px;">15|LNV|26-12-2017</p> 
				   <p style="margin: 0;">For 10, Institutional Area, Lodi Road</p> 
				   <p style="margin: 0;">New Delhi, 110003</p> 
				   <p style="margin: 0;">India</p>
    
		  </div>
		   <div style="width:43%;  background:#FFF;  padding:20px;float:left;">
			  
				   <p style="margin: 0;font-size: 16px;">15|LNV|26-12-2017</p> 
				   <p style="margin: 0;">For 10, Institutional Area, Lodi Road</p> 
				   <p style="margin: 0;">New Delhi, 110003</p> 
				   <p style="margin: 0;">India</p>
    
		  </div>
		   <div style="width:43%;  background:#FFF;  padding:20px;float:left;">
			  
				   <p style="margin: 0;font-size: 16px;">15|LNV|26-12-2017</p> 
				   <p style="margin: 0;">For 10, Institutional Area, Lodi Road</p> 
				   <p style="margin: 0;">New Delhi, 110003</p> 
				   <p style="margin: 0;">India</p>
    
		  </div>
		   <div style="width:43%;  background:#FFF;  padding:20px;float:left;">
			  
				   <p style="margin: 0;font-size: 16px;">15|LNV|26-12-2017</p> 
				   <p style="margin: 0;">For 10, Institutional Area, Lodi Road</p> 
				   <p style="margin: 0;">New Delhi, 110003</p> 
				   <p style="margin: 0;">India</p>
    
		  </div>
	</body>
</html>
	';			

include("mpdf.php");
$mpdf=new mPDF('en-GB-x','A4','','',10,10,10,10,6,3);
$mpdf->SetDisplayMode('fullpage');
$mpdf->WriteHTML($html);
$mpdf->Output($path,'F');

///include("mpdf.php");
//$mpdf=new mPDF('c','A4','','',32,25,27,25,16,13); 
//$mpdf=new mPDF('en-GB-x','A4','','',10,10,10,10,6,3);
//$mpdf->SetDisplayMode('fullpage');
//$mpdf->list_indent_first_level = 0;	// 1 or 0 - whether to indent the first level of a list
//$mpdf->WriteHTML($html,2);
//$mpdf->WriteHTML($html);
//$mpdf->WriteHTML($html);

//$mpdf->Output('mpdf.pdf','I');
 //$mpdf->Output('mpdf.pdf','F');
exit;
//==============================================================
//==============================================================
//==============================================================


?>